#include "StdAfx.h"
#include "Categoria.h"

Categoria::Categoria(){
}

Categoria::Categoria(int _id,string _nombre,ListaDeEmpresas _listaDeEmpresas)
{
	id=_id;
	nombre=_nombre;
	listaDeEmpresas=_listaDeEmpresas;
}

int Categoria::getId(){ return id; }
string Categoria::getNombre(){ return nombre; }
ListaDeEmpresas Categoria::getListaDeEmpresas(){ return listaDeEmpresas; }

void Categoria::setId(int _id){ id=_id; }
void Categoria::setNombre(string _nombre){ nombre=_nombre; } 
void Categoria::setListaDeEmpresas(ListaDeEmpresas _listaDeEmpresas){
	listaDeEmpresas=_listaDeEmpresas;
}