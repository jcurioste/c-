#pragma once
#include <iostream>
using namespace std;
#include <string.h>
#include "ListaDeEmpresas.h"

class Categoria
{
private:
	int id;
	string nombre;
	ListaDeEmpresas listaDeEmpresas;
public:
	Categoria();
	Categoria(int,string,ListaDeEmpresas);

	int getId();
	string getNombre();
	ListaDeEmpresas getListaDeEmpresas();

	void setId(int);
	void setNombre(string);
	void setListaDeEmpresas(ListaDeEmpresas);
};

