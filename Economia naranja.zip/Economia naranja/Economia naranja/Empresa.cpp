#include "StdAfx.h"
#include "Empresa.h"


Empresa::Empresa(){
}

Empresa::Empresa(int _id,string _nombre,string _descripcion,string _email,int _telefono)
{
	id=_id;
	nombre=_nombre;
	descripcion=_descripcion;
	email=_email;
	telefono=_telefono;
}

int Empresa::getId(){ return id; }
string Empresa::getNombre(){ return nombre; }
string Empresa::getDescripcion(){ return descripcion; }
string Empresa::getEmail(){ return email; }
int Empresa::getTelefono(){ return telefono; }

void Empresa::setId(int _id){ id=_id; }
void Empresa::setNombre(string _nombre){ nombre=_nombre; } 
void Empresa::setDescripcion(string _descripcion){ descripcion=_descripcion; }
void Empresa::setEmail(string _email){ email=_email; }
void Empresa::setTelefono(int _telefono){ telefono=_telefono; }
