#pragma once
#include <iostream>
using namespace std;
#include <string.h>


class Empresa
{
private:
	int id;
	string nombre;
	string descripcion;
	string email;
	int telefono;
public:
	Empresa();
	Empresa(int,string,string,string,int);
	
	int getId();
	string getNombre();
	string getDescripcion();
	string getEmail();
	int getTelefono();

	void setId(int);
	void setNombre(string);
	void setDescripcion(string);
	void setEmail(string);
	void setTelefono(int);

};

