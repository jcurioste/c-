#pragma once
#include "ListaDeCategorias.h"
#include "ListaDeEmpresas.h"
#include "InformacionEmpresa.h"
#include "Empresa.h"

#include <iostream>
using namespace std;
#include <string.h>

#include <msclr\marshal_cppstd.h>
#include "stdafx.h"

namespace Economianaranja {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	using namespace msclr::interop;


	static ListaDeCategorias listaDeCategorias;
	static string nombreCategoria;

	/// <summary>
	/// Resumen de Empresas
	/// </summary>
	public ref class Empresas : public System::Windows::Forms::Form
	{
	public:
		Empresas(String^ nombreCat,ListaDeCategorias _listaDeCategorias)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			listaDeCategorias=_listaDeCategorias;
			nombreCategoria=marshal_as<std::string>(nombreCat);
		}

	//metodo para convertir de string a ansiString
		String^ toStringObject(string texto){
			return gcnew String(texto.c_str());
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Empresas()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Button^  button1;
	protected: 

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;
		

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Empresas::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label1->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI Semibold", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label1->Location = System::Drawing::Point(185, 35);
			this->label1->Name = L"label1";
			this->label1->Padding = System::Windows::Forms::Padding(15);
			this->label1->Size = System::Drawing::Size(433, 76);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Empresas de la categoria";
			// 
			// comboBox1
			// 
			this->comboBox1->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->comboBox1->ForeColor = System::Drawing::SystemColors::Window;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(251, 222);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(323, 37);
			this->comboBox1->TabIndex = 2;
			this->comboBox1->Text = L"Seleccione una empresa";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->button1->Location = System::Drawing::Point(330, 351);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(164, 58);
			this->button1->TabIndex = 3;
			this->button1->Text = L"Aceptar";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Empresas::button1_Click);
			// 
			// Empresas
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(824, 481);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label1);
			this->Name = L"Empresas";
			this->Text = L"Empresas";
			this->Load += gcnew System::EventHandler(this, &Empresas::Empresas_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Empresas_Load(System::Object^  sender, System::EventArgs^  e) {
				//carga las opciones
				int index=0;
				for (int i=0; i<listaDeCategorias.size(); i++){
					if (nombreCategoria==listaDeCategorias.get(i).getNombre()){
						index=i;
					}
				}		

				ListaDeEmpresas listaDeEmpresas;
				listaDeEmpresas=listaDeCategorias.get(index).getListaDeEmpresas();

				for (int i=0; i<listaDeEmpresas.size(); i++){
					comboBox1->Items->Add( toStringObject(listaDeEmpresas.get(i).getNombre()) );
				}
				
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			//carga las opciones
				int index=0;
				for (int i=0; i<listaDeCategorias.size(); i++){
					//comboBox1->Items->Add( toStringObject( ---    ) );
					if (nombreCategoria==listaDeCategorias.get(i).getNombre()){
						index=i;
					}
				}
			 
			 ListaDeEmpresas listaDeEmpresas;
			listaDeEmpresas=listaDeCategorias.get(index).getListaDeEmpresas();

			 for (int i=0; i<listaDeEmpresas.size(); i++){
				 if (toStringObject(listaDeEmpresas.get(i).getNombre())==comboBox1->Text ){
					empresa=listaDeEmpresas.get(i);
				 }
				}
			 InformacionEmpresa^ informacion = gcnew InformacionEmpresa(empresa);
			 informacion->Show();
		 }
};
}
//listaDeCategorias.get(i).getListaDeEmpresas(index);