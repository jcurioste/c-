#pragma once
#include "ListaDeCategorias.h"
#include "Categoria.h"
#include "ListaDeEmpresas.h"
#include "Empresa.h"
#include "Empresas.h"

#include <iostream>
using namespace std;
#include <string.h>

namespace Economianaranja {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	

	/// <summary>
	/// Resumen de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
	
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

		//metodo para convertir de string a ansiString
		String^ toStringObject(string texto){
			return gcnew String(texto.c_str());
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label2;
	protected: 

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;
		
		

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label1->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI Semibold", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label1->Location = System::Drawing::Point(316, 26);
			this->label1->Name = L"label1";
			this->label1->Padding = System::Windows::Forms::Padding(15);
			this->label1->Size = System::Drawing::Size(326, 76);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Economia naranja";
			// 
			// comboBox1
			// 
			this->comboBox1->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->comboBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->comboBox1->ForeColor = System::Drawing::SystemColors::Window;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(319, 283);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(323, 37);
			this->comboBox1->TabIndex = 1;
			this->comboBox1->Text = L"Seleccione una categoria";
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox1_SelectedIndexChanged);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->button1->Location = System::Drawing::Point(404, 446);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(164, 58);
			this->button1->TabIndex = 2;
			this->button1->Text = L"Aceptar";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label2->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI Semibold", 16, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label2->Location = System::Drawing::Point(342, 133);
			this->label2->Name = L"label2";
			this->label2->Padding = System::Windows::Forms::Padding(15);
			this->label2->Size = System::Drawing::Size(281, 67);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Servicios culturales";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(948, 613);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void comboBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 }

	//SE EJECUTA AL INICIAR EL PROGRAMA
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
				

				//a�ade la lista de empresas para la categoria cine
				ListaDeEmpresas listaDeEmpresasCine;
					Empresa empresaCine1(1,"MultiCine","Cadena de cines internacional","multicine@gmail.com",78579772);
					Empresa empresaCine2(2,"Cine2","Cine boliviano","cine2gmail.com",2141243321);
					
				listaDeEmpresasCine.add(empresaCine1);
				listaDeEmpresasCine.add(empresaCine2);


				//a�ade la lista de empresas para la categoria teatro
				ListaDeEmpresas listaDeEmpresasTeatro;
					Empresa empresaTeatro1(1,"Dream Theater","Teatro nacional","dream_theater@gmail.com",78579772);
				listaDeEmpresasTeatro.add(empresaTeatro1);


				//a�ade la lista de empresas para la categoria nombre
				ListaDeEmpresas listaDeEmpresasNombre;
					Empresa empresaNombre1(1,"Dream Theater","Teatro nacional","dream_theater@gmail.com",78579772);
				listaDeEmpresasNombre.add(empresaTeatro1);

				//a�ade la lista de empresas para la categoria restaurante
				ListaDeEmpresas listaDeEmpresasRestaurante;
				Empresa empresaRestaurante1(1, "Casa del Camba", "El restaurante la casa del camba lleva m�s de 20 a�os ofreciendo la mejor comida criolla a nivel departamentalActualmente sus servicios son de manera presencial en los dos establecimientos y tambi�n mediante delivery.", "casadelcamba@gmail.com", 76003877);
				Empresa empresaRestaurante2(2, "El ajibe","El ajibe abre sus puertas exactamente el 27 de enero del 2009, desde aquel entonces el ajibe representa la comida t�pica cruce�a con orgullo, con una preparaci�n y sabores exquisitos, el ajibe atiende de manera presencial y mediante delivery. ", "info@elajibecomidatipica.com", 3352277);
				listaDeEmpresasRestaurante.add(empresaRestaurante1);
				listaDeEmpresasRestaurante.add(empresaRestaurante2);

				//a�ade la lista de empresas para la categoria textiles
				ListaDeEmpresas listaDeEmpresasTextiles;
				Empresa empresaTextiles1(1, "Entretelas", "Textiles bolivianos", "www.entretelas.com.bo", 77600240);
				Empresa empresaTextiles1(2, "Importex", "Textiles bolivianos", "importex1973@gmail.com", 72636822);
				listaDeEmpresasTextiles.add(empresaTextiles1);
				//A�ade las categorias
				Categoria categoriaCine(1,"Cine",listaDeEmpresasCine);
				Categoria categoriaTeatro(2,"Teatro",listaDeEmpresasTeatro);
				Categoria categoriaNombre(3,"Nombre",listaDeEmpresasNombre);
				Categoria categoriaRestaurante(4, "Restaurante", listaDeEmpresasRestaurante);
				Categoria categoriaTextiles(5, "Textiles", listaDeEmpresasTextiles);
				//a�ade las categorias a la lista de categorias
				listaDeCategorias.add(categoriaCine);
				listaDeCategorias.add(categoriaTeatro);
				listaDeCategorias.add(categoriaNombre);
				listaDeCategorias.add(categoriaRestaurante);
				listaDeCategorias.add(categoriaTextiles);
				//Carga las opciones de categoria desde la lista de categorias
				for (int i=0; i<listaDeCategorias.size(); i++){
					comboBox1->Items->Add( toStringObject(listaDeCategorias.get(i).getNombre()) );
				}
				
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 Empresas^ empresas = gcnew Empresas(comboBox1->Text,listaDeCategorias);
			 empresas->Show();
		 }
};
}

