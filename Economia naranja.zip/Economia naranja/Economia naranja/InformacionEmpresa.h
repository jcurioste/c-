#pragma once
#include "Empresa.h"

namespace Economianaranja {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	static Empresa empresa;

	/// <summary>
	/// Resumen de InformacionEmpresa
	/// </summary>
	public ref class InformacionEmpresa : public System::Windows::Forms::Form
	{
	public:
		InformacionEmpresa(Empresa _empresa)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
			empresa=_empresa;
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~InformacionEmpresa()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::RichTextBox^  richTextBox2;
	private: System::Windows::Forms::RichTextBox^  richTextBox3;
	protected: 

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(InformacionEmpresa::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox2 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox3 = (gcnew System::Windows::Forms::RichTextBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label1->Font = (gcnew System::Drawing::Font(L"Yu Gothic UI Semibold", 20, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->label1->Location = System::Drawing::Point(199, 61);
			this->label1->Name = L"label1";
			this->label1->Padding = System::Windows::Forms::Padding(15);
			this->label1->Size = System::Drawing::Size(294, 76);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Informacion de ";
			this->label1->Click += gcnew System::EventHandler(this, &InformacionEmpresa::label1_Click);
			// 
			// richTextBox1
			// 
			this->richTextBox1->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->richTextBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox1->ForeColor = System::Drawing::SystemColors::Window;
			this->richTextBox1->Location = System::Drawing::Point(207, 181);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(624, 202);
			this->richTextBox1->TabIndex = 3;
			this->richTextBox1->Text = L"Esto es un texto de prueba";
			// 
			// richTextBox2
			// 
			this->richTextBox2->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->richTextBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox2->ForeColor = System::Drawing::SystemColors::Window;
			this->richTextBox2->Location = System::Drawing::Point(207, 403);
			this->richTextBox2->Name = L"richTextBox2";
			this->richTextBox2->Size = System::Drawing::Size(624, 45);
			this->richTextBox2->TabIndex = 4;
			this->richTextBox2->Text = L"Email: ";
			// 
			// richTextBox3
			// 
			this->richTextBox3->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->richTextBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->richTextBox3->ForeColor = System::Drawing::SystemColors::Window;
			this->richTextBox3->Location = System::Drawing::Point(207, 472);
			this->richTextBox3->Name = L"richTextBox3";
			this->richTextBox3->Size = System::Drawing::Size(624, 45);
			this->richTextBox3->TabIndex = 5;
			this->richTextBox3->Text = L"Telefono";
			// 
			// InformacionEmpresa
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(937, 568);
			this->Controls->Add(this->richTextBox3);
			this->Controls->Add(this->richTextBox2);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->label1);
			this->Name = L"InformacionEmpresa";
			this->Text = L"InformacionEmpresa";
			this->Load += gcnew System::EventHandler(this, &InformacionEmpresa::InformacionEmpresa_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void InformacionEmpresa_Load(System::Object^  sender, System::EventArgs^  e) {
				 label1->Text="Informacion de "+gcnew String(empresa.getNombre().c_str());
					richTextBox1->Text=gcnew String(empresa.getDescripcion().c_str());
					richTextBox2->Text=gcnew String(empresa.getEmail().c_str());
					richTextBox3->Text=System::Convert::ToString(empresa.getTelefono());
			 }
	};
}
