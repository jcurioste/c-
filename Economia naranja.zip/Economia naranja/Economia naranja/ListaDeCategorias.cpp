#include "StdAfx.h"
#include "ListaDeCategorias.h"


ListaDeCategorias::ListaDeCategorias(){
	cantidad=0;
}

void ListaDeCategorias::add(Categoria Categoria){
	lista[cantidad]=Categoria;
	cantidad++;
}

Categoria ListaDeCategorias::get(int index){
	
	if (!(index>=0 && index<cantidad)){
		//error
	}
	return lista[index];
}

void ListaDeCategorias::remove(int index){
	
	if (index>=0 && index<cantidad){
		for (int i=index; i<cantidad-1; i++){
			lista[i]=lista[i+1];
		}
		cantidad--;
	}else{
	//error
	}
}

int ListaDeCategorias::size(){
	return cantidad;
}