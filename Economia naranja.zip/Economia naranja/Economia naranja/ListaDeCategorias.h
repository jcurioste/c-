#pragma once
#include <iostream>
using namespace std;
#include "Categoria.h"

class ListaDeCategorias
{
private:
	Categoria lista[10];
	int cantidad;
public:
	ListaDeCategorias();

	void add(Categoria);
	Categoria get(int);
	void remove(int);
	int size();
};