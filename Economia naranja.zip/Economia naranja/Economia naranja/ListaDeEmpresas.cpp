#include "StdAfx.h"
#include "ListaDeEmpresas.h"


ListaDeEmpresas::ListaDeEmpresas(){
	cantidad=0;
}

void ListaDeEmpresas::add(Empresa empresa){
	lista[cantidad]=empresa;
	cantidad++;
}

Empresa ListaDeEmpresas::get(int index){
	
	if (!(index>=0 && index<cantidad)){
		//error
	}
	return lista[index];
}

void ListaDeEmpresas::remove(int index){
	
	if (index>=0 && index<cantidad){
		for (int i=index; i<cantidad-1; i++){
			lista[i]=lista[i+1];
		}
		cantidad--;
	}else{
	//error
	}
}

int ListaDeEmpresas::size(){
	return cantidad;
}