#pragma once
#include <iostream>
using namespace std;
#include "Empresa.h"

class ListaDeEmpresas
{
private:
	Empresa lista[100];
	int cantidad;
public:
	ListaDeEmpresas();

	void add(Empresa);
	Empresa get(int);
	void remove(int);
	int size();
};
